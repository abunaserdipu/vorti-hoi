<div class="row p-0 m-0">
    <div class="col-md-3">
        <nav class="navbar bg-light">
            <div class="container-fluid">
                <ul class="navbar-nav" style="height: 500px;">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('admin/circulars') ?>">Circular</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('applications') ?>">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Notice</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>